import { NextResponse } from 'next/server';
import { adminServices, requireUser } from '@/lib/firebase-admin';
import { apiError, limited } from '@/lib/api';
import { evaluationSchema } from '@/lib/schemas';
import { aggregate } from '@/lib/rubric';
export const runtime='nodejs';
export async function POST(request:Request) {
  try {
    const uid=await requireUser(request); if(!await limited(uid)) return NextResponse.json({error:'Too many requests.'},{status:429});
    const text=await request.text(); if(text.length>1000) return NextResponse.json({error:'Request too large.'},{status:413});
    let data:unknown; try { data=JSON.parse(text); } catch {return NextResponse.json({error:'Invalid JSON.'},{status:400});}
    const id=typeof data==='object' && data!==null && 'sessionId' in data ? data.sessionId : null;
    if(typeof id!=='string' || !/^[A-Za-z0-9_-]{1,128}$/.test(id)) return NextResponse.json({error:'Invalid session.'},{status:400});
    const {db}=adminServices();const ref=db.collection('sessions').doc(id);const snapshot=await ref.get();const session=snapshot.data();
    if(!session || session.uid!==uid)return NextResponse.json({error:'Session not found.'},{status:404});
    if(session.status!=='done')return NextResponse.json({error:'Complete the interview first.'},{status:409});
    const docs=await ref.collection('turns').orderBy('index').get(); const turns=docs.docs.map(d=>d.data());
    if(!turns.length)return NextResponse.json({error:'No answers available.'},{status:409});
    const evaluations=turns.map(t=>evaluationSchema.parse(t.evaluation));const {overall,subscores}=aggregate(evaluations);
    const strengths=evaluations.flatMap(e=>e.strengths).slice(0,3);const improvements=evaluations.flatMap(e=>e.weaknesses).slice(0,3);
    // NOT_IMPLEMENTED: Generic practice plan, not a personalized AI-generated final report.
    const practicePlan=['Review your interview questions and mark the topics to revisit.','Study one core concept and summarize it in your own words.','Practice one answer aloud using a concrete example.','Review gaps and seek reliable reference material.','Try a timed practice answer and revise its structure.','Revisit a difficult question and explain your reasoning.','Repeat a practice interview and reflect on changes.'];
    await ref.update({overall,subscores});
    return NextResponse.json({overall,subscores,strengths,improvements,practicePlan,turns,demo:session.demo,role:session.role,startedAt:session.startedAt});
  }catch(error){return apiError(error);}
}
