import 'server-only';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import OpenAI from 'openai';
import { validateWithRetry } from './rubric';
import type { Evaluation } from './schemas';

// Groq's documented OpenAI-compatible endpoint; no secrets reach client code.
export async function evaluateAnswer(question: string, answer: string): Promise<Evaluation> {
  const apiKey = process.env.GROQ_API_KEY;
  const model = process.env.OPENAI_CHAT_MODEL;
  if (!apiKey || !model) throw new Error('Groq evaluation is not configured');
  const system = await readFile(path.join(process.cwd(), 'prompts/evaluate-answer.md'), 'utf8');
  const client = new OpenAI({ apiKey, baseURL: 'https://api.groq.com/openai/v1', timeout: 20000, maxRetries: 2 });
  const scoreProperties = Object.fromEntries(['correctness','depth','clarity','structure','relevance'].map(k => [k,{type:'number'}]));
  const textArray = {type:'array', items:{type:'string'}};
  const schema = {type:'object',additionalProperties:false,required:['scores','strengths','weaknesses','idealOutline','tip'],properties:{scores:{type:'object',additionalProperties:false,required:Object.keys(scoreProperties),properties:scoreProperties},strengths:textArray,weaknesses:textArray,idealOutline:textArray,tip:{type:'string'}}};
  return validateWithRetry(async () => {
    const started = Date.now();
    try {
      const result = await client.chat.completions.create({ model, temperature: 0, max_completion_tokens: 1000, response_format:{type:'json_schema',json_schema:{name:'evaluation',strict:true,schema}}, messages:[{role:'system',content:system},{role:'user',content:JSON.stringify({untrusted_question:question,untrusted_answer:answer})}] });
      console.info(JSON.stringify({event:'evaluation',latencyMs:Date.now()-started,usage:result.usage ?? null}));
      return result.choices[0]?.message.content ?? '';
    } catch (error) { console.warn(JSON.stringify({event:'evaluation_error',latencyMs:Date.now()-started})); throw error; }
  });
}
