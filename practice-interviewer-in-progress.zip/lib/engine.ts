export type Seniority = 'junior' | 'mid' | 'senior';
export type Question = { id: string; text: string; topic: string; difficulty: number };
export type Turn = { question: Question; answerText: string };
export type InterviewState = { turns: Turn[]; timeLeftSec: number; topicsCovered: string[]; lastScore: number | null; targetCount: number; seniority: Seniority; topics: string[] };
export type Decision = { action: 'open' | 'follow_up' | 'new_topic' | 'probe_or_clarify' | 'clarify' | 'close'; difficulty: number; topic: string };

/** Deterministic policy; selection of a unique question is handled by the bank. */
export function nextQuestion(state: InterviewState): Decision {
  if (state.topics.length === 0) throw new Error('At least one topic is required');
  const previous = state.turns.at(-1);
  const initialDifficulty = { junior: 2, mid: 3, senior: 4 }[state.seniority];
  const difficulty = previous?.question.difficulty ?? initialDifficulty;
  const topic = previous?.question.topic ?? state.topics[0];
  if (state.timeLeftSec < 90 || state.turns.length >= state.targetCount) return { action: 'close', difficulty, topic };
  if (!previous) return { action: 'open', difficulty, topic };
  if (previous.answerText.trim().split(/\s+/).filter(Boolean).length < 15) return { action: 'clarify', difficulty, topic };
  if (state.lastScore === null || !Number.isFinite(state.lastScore) || state.lastScore < 0 || state.lastScore > 10) throw new Error('A score from 0 to 10 is required');
  if (state.lastScore >= 7.5) return { action: 'follow_up', difficulty: Math.min(difficulty + 1, 5), topic };
  if (state.lastScore < 4) return { action: 'probe_or_clarify', difficulty: Math.max(difficulty - 1, 1), topic };
  const uncovered = state.topics.find(t => !state.topicsCovered.includes(t) && t !== topic);
  const other = state.topics.find(t => t !== topic);
  return { action: 'new_topic', difficulty, topic: uncovered ?? other ?? topic };
}
