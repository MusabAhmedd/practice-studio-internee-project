/** Counts common English fillers; transcription may omit fillers, so results are approximate. */
export function speechMetrics(text:string,durationSec:number) {
  const words=text.trim().match(/[\p{L}\p{N}]+(?:['’][\p{L}]+)?/gu) ?? [];
  const fillers=words.filter(w=>/^(um|uh)$/i.test(w)).length;
  return {wordCount:words.length,fillers,wordsPerMinute:durationSec>0?Math.round(words.length*60/durationSec):null};
}
