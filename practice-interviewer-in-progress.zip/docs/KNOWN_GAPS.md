# Known gaps

- NOT_IMPLEMENTED: Streaming interview responses, adaptive LLM question phrasing, personalized final-report generation, TTS, resume uploads, code-answer review, dashboard/history charts, demo seeding, real-data ingestion, health endpoint, CI, deployment, and shadcn/ui components.
- NOT_IMPLEMENTED: Full Firestore security-rule test suite, adversarial prompt-injection tests, robust upload content inspection, distributed abuse controls, and explicit session token budget accounting. The provisional Firestore rules are not production-ready. Do not apply them to a real project.
- Demo scoring in `lib/demo-evaluation.ts` is a length-based illustrative fixture, not AI. Demo mode must be explicitly enabled. Do not use demo scores as performance assessments.
- Groq chat evaluation and Groq audio transcription are implemented but NOT RUN against the provider. A replacement Groq key and a supported model must be privately configured before live tests. The exposed key was not stored.
- M4's three-question gate and M5's PDF gate passed in SAMPLE demo mode with emulated Firebase, not with live AI. Streaming and personalized report generation remain missing.
- M6 is NOT PASSED: metrics tests and the voice-disabled/text fallback test passed, but a real voice answer has not been transcribed. Under the requested milestone rules, M7–M9 have not been started.
- Google popup and live Firebase have not been tested. No changes were made to the user's real Firebase project.
- Question selection uses the nearest available bank difficulty if an exact one is unavailable, and no LLM rephrasing is implemented. The current sample question bank does not distinguish interview type.
- Session completion and report aggregation are basic; the three strengths and weaknesses are the first available entries, not deduplicated or ranked. The seven-day plan is generic.
- Setup's direct Firestore writes and the temporary session schema need security review and alignment with the requested production schema. Current rate limits use Firestore transactions but have not been stress-tested.
