# Demo walkthrough — SAMPLE ONLY, work in progress

This uses local Firebase emulators and simulated, length-based scores. It is not a test of Groq or a real assessment. Set up the emulator environment described in the README.

1. Create a disposable emulator account and sign in. Select a role and start practice.
2. Answer three questions. Try the hint, skip, and focus mode controls. Voice requires a separately configured Groq transcription model and has not been live-tested.
3. Open the report, inspect the radar chart and answer breakdown, and use Print / save as PDF. The 7-day plan is generic and the demo scores are not meaningful.

Current gaps are listed in `docs/KNOWN_GAPS.md`.
