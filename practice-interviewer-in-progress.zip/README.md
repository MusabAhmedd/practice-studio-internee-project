# Practice Studio — work in progress

An interview-practice application for role-based preparation, **not a hiring assessment**. A three-question SAMPLE demo works with local Firebase emulators. It is not production-ready. See [known gaps](docs/KNOWN_GAPS.md) before use.

## Architecture

```mermaid
flowchart LR
  B[Browser: Next.js UI] -->|Firebase ID token| API[Next.js API routes]
  B -->|Auth and provisional setup writes| FB[Firebase Auth and Firestore]
  API -->|Admin SDK| FB
  API --> E[Deterministic engine and SAMPLE question bank]
  API -->|server key only| G[Groq OpenAI-compatible API]
  API --> D[Optional simulated demo scoring]
```

Demo scoring uses answer length and is NOT AI. It is visibly labelled SAMPLE and must never be used to judge performance. Real Groq calls have not been tested.

## Stack and versions

Next.js 16.4.6, React 19.3.1, TypeScript 5.9.3, Tailwind CSS 4.3.5, Firebase 13.4.0, firebase-admin 14.5.1, OpenAI-compatible SDK 7.62.0, Zod 4.6.7, Recharts 3.11.0. shadcn/ui is not yet integrated. Node 24.22.3 was used for the latest tests. Full dependency versions are locked in `package-lock.json`. Local Firebase emulators require Java 21; Playwright requires Chromium and OS libraries.

## Local SAMPLE demo

Only use a demo project; never point this test at a real Firebase project. In separate terminals, after installing Node 24.22.3 and Java 21:

```sh
npm ci
npx firebase emulators:start --only auth,firestore --project demo-interview-test
# In another terminal, build the test-only client:
NEXT_PUBLIC_USE_EMULATORS=true npm run build
# Start the test-only app:
DEMO_MODE=true FIREBASE_PROJECT_ID=demo-interview-test \
FIREBASE_AUTH_EMULATOR_HOST=127.0.0.1:9099 FIRESTORE_EMULATOR_HOST=127.0.0.1:8080 \
npm run start
```

Open localhost:3000 in a browser on the same computer, create an emulator account, and start a session. This emulator mode is not suitable for a remotely proxied browser because the browser connects to local emulator ports. `NEXT_PUBLIC_USE_EMULATORS` is baked into the client build: rebuild without it before any non-emulator use. Never enable demo or emulator flags in production. The provisional rules have not been reviewed for production; do not deploy them to the user's real project.

`.env.example` lists environment variables. A replacement Groq key must be stored privately as `GROQ_API_KEY`; no live transcription has been tested. Groq documents `whisper-large-v3-turbo` as a speech-to-text model; set `OPENAI_STT_MODEL` to a model available on your account. `OPENAI_CHAT_MODEL` must support Groq strict JSON schema. Availability, quota and behavior are provider-dependent. Do not paste secret keys in chat.

## Verification

- Build: `NEXT_PUBLIC_USE_EMULATORS=true npm run build` passed.
- Engine: `npm run test:engine` passed; `docs/eval/M2-engine-test.txt`.
- Rubric: `npm run test:rubric` passed using a mocked transport; `docs/eval/M3-rubric-test.txt`.
- Three-question session and generated sample PDF: `docs/eval/M5-report-test.txt`, `docs/SAMPLE_report.pdf`. This used simulated scores and emulators.
- Voice metrics and voice-disabled text fallback: `docs/eval/M6-speech-metrics-test.txt` and `docs/eval/M6-e2e-tests.txt`.
- Actual transcription, live Groq evaluation, M7–M9, CI and deployment: **NOT RUN**. M6 gate is not passed.

The three browser tests require emulators and an emulator-built application at port 3001; run `npx playwright test tests/e2e --workers=1`. The Playwright-generated PDF is labelled SAMPLE. See `docs/DEMO_SCRIPT.md` for a walkthrough.

## Limitations and future work

Not production-ready: see `docs/KNOWN_GAPS.md`. The report is generic, there is no history dashboard, no tested security rules, no TTS, no streaming, and no live provider evaluation. A production release needs a security review, real provider calibration, complete end-to-end coverage and deployment verification.
