import { test } from 'node:test';
import assert from 'node:assert/strict';
import { speechMetrics } from '../lib/speech-metrics';
test('counts fillers and pace',()=>{assert.deepEqual(speechMetrics('Um this is uh an example',3),{wordCount:6,fillers:2,wordsPerMinute:120});});
test('handles zero duration and whitespace',()=>{assert.deepEqual(speechMetrics('   ',0),{wordCount:0,fillers:0,wordsPerMinute:null});});
